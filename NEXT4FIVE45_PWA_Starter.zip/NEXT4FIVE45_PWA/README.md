# NEXT4FIVE45 PWA starter

## Isi paket
- `index.html`: landing page komunitas dengan WhatsApp dan tombol bagikan/install
- `manifest.webmanifest`: metadata instalasi PWA
- `sw.js`: cache offline dasar
- `admin.html`: panel draf lokal (BUKAN admin publik yang aman)
- `icons/`: ikon placeholder NX45, dapat diganti dengan logo resmi

## Nomor WhatsApp
Nomor yang diberikan `087721873603` sudah dinormalisasi menjadi format tautan internasional `6287721873603`.

## Deploy ke GitHub Pages
1. Ekstrak ZIP.
2. Unggah semua isi folder (bukan folder pembungkusnya) ke root repositori `NEXT4FIVE-45-UBY-UNGU`.
3. Commit perubahan.
4. Pastikan Settings > Pages menggunakan `Deploy from a branch`, branch `main`, folder `/(root)`.
5. Buka `https://maulanadirham40-png.github.io/NEXT4FIVE-45-UBY-UNGU/`.
6. Pastikan halaman berjalan melalui HTTPS. Di Chrome Android, menu ⋮ > Tambahkan ke layar utama / Install app.

## Membuat APK
Paket ini adalah sumber PWA, bukan APK yang sudah dikompilasi. Setelah website live, gunakan pembungkus PWA Android tepercaya atau PWABuilder untuk membuat paket Android; ikuti instruksi resminya untuk memasukkan URL publik, nama aplikasi, package ID (mis. `com.next4five45.community`) dan ikon. APK yang ditandatangani perlu dibuat dan dikelola dengan kunci signing milik pemilik.

## PENTING: admin
`admin.html` hanya panel demo lokal. Kode demo `NX45-DEMO` dapat dilihat dari sumber halaman dan tidak aman. Draf hanya tersimpan di browser perangkat lokal dan tidak mengubah website yang dilihat orang lain. Jangan promosikan panel ini sebagai admin aman. Untuk fitur admin sungguhan (login pemilik, edit konten global, unggah logo), perlu backend + autentikasi server dan aturan akses.
